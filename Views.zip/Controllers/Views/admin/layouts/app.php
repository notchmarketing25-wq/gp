<?php
if (!function_exists('_st')) {
    function _st(string $k, string $d = ''): string {
        try { return SettingModel::get($k, $d); } catch (\Throwable $e) { return $d; }
    }
}
if (!function_exists('_au')) {
    function _au(): ?array {
        try { return Session::get('admin_user'); } catch (\Throwable $e) { return null; }
    }
}
$_name = _st('store_name', defined('APP_NAME') ? APP_NAME : 'Notch');
$_user = _au() ?? ['name' => 'Admin', 'role' => ''];
$_pfx  = defined('ADMIN_PREFIX') ? ADMIN_PREFIX : 'admin';
$_uri  = $_SERVER['REQUEST_URI'] ?? '';
$_pend = 0;
try { $_pend = (int)(Database::fetch("SELECT COUNT(*) c FROM orders WHERE status='pending'")['c'] ?? 0); } catch (\Throwable $e) {}

function nav_active(string $match, string $uri): string {
    return preg_match('#'.$match.'#', $uri) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($pageTitle ?? 'لوحة التحكم') ?> · <?= htmlspecialchars($_name) ?></title>
<style>
/* ══════════ RESET ══════════ */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{height:100%}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  background:#0d0d0f;color:#e2e2ea;font-size:14px;line-height:1.5;
  min-height:100%;direction:rtl}
a{text-decoration:none;color:inherit}
button{font-family:inherit;cursor:pointer}
img{display:block;max-width:100%}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:#2e2e38;border-radius:10px}

/* ══════════ TOKENS ══════════ */
:root{
  --bg:       #0d0d0f;
  --bg1:      #111115;
  --bg2:      #16161c;
  --bg3:      #1c1c24;
  --bd:       #25252f;
  --bd2:      #2e2e3a;
  --t1:       #e2e2ea;
  --t2:       #8888a0;
  --t3:       #44445a;
  --ac:       #7c5cfc;
  --ac2:      #9b7fff;
  --acb:      rgba(124,92,252,.12);
  --acb2:     rgba(124,92,252,.22);
  --green:    #22c55e;
  --red:      #ef4444;
  --yellow:   #f59e0b;
  --blue:     #3b82f6;
  --radius:   10px;
  --radius-s: 7px;
  --sidebar:  224px;
  --topbar:   52px;
  --shadow:   0 2px 12px rgba(0,0,0,.4);
}

/* ══════════ LAYOUT ══════════ */
.layout{display:flex;min-height:100vh}

/* ── SIDEBAR ── */
.sidebar{
  width:var(--sidebar);flex-shrink:0;
  background:var(--bg1);
  border-left:1px solid var(--bd);
  position:fixed;top:0;right:0;bottom:0;
  display:flex;flex-direction:column;
  z-index:200;
  transition:transform .25s ease;
}
.sb-logo{
  height:var(--topbar);
  padding:0 14px;
  border-bottom:1px solid var(--bd);
  display:flex;align-items:center;gap:10px;
  flex-shrink:0;
}
.sb-logo-mark{
  width:28px;height:28px;border-radius:7px;flex-shrink:0;
  background:linear-gradient(135deg,var(--ac),var(--ac2));
  display:flex;align-items:center;justify-content:center;font-size:14px;
}
.sb-logo-text{font-size:13px;font-weight:700;color:var(--t1)}
.sb-logo-text small{display:block;font-size:10px;font-weight:400;color:var(--t3)}

.sb-nav{flex:1;overflow-y:auto;padding:8px 6px}
.sb-section{
  font-size:10px;font-weight:600;color:var(--t3);
  text-transform:uppercase;letter-spacing:.9px;
  padding:14px 8px 5px;
}
.sb-link{
  display:flex;align-items:center;gap:9px;
  padding:7px 10px;border-radius:var(--radius-s);
  font-size:13px;font-weight:500;color:var(--t2);
  margin-bottom:1px;transition:background .12s,color .12s;
  position:relative;
}
.sb-link:hover{background:var(--bg3);color:var(--t1)}
.sb-link.active{background:var(--acb2);color:var(--ac2)}
.sb-link.active::after{
  content:'';position:absolute;right:0;top:6px;bottom:6px;
  width:3px;background:var(--ac);border-radius:2px 0 0 2px;
}
.sb-icon{font-size:16px;width:20px;text-align:center;flex-shrink:0}
.sb-badge{
  margin-right:auto;background:var(--red);color:#fff;
  font-size:10px;font-weight:700;padding:1px 6px;border-radius:20px;
  min-width:18px;text-align:center;
}

.sb-footer{
  padding:8px 6px;border-top:1px solid var(--bd);flex-shrink:0;
}
.sb-user{
  display:flex;align-items:center;gap:9px;
  padding:7px 10px;border-radius:var(--radius-s);
  transition:background .12s;
}
.sb-user:hover{background:var(--bg3)}
.sb-avatar{
  width:28px;height:28px;border-radius:50%;flex-shrink:0;
  background:var(--acb2);border:1.5px solid var(--ac);
  display:flex;align-items:center;justify-content:center;
  font-size:11px;font-weight:700;color:var(--ac2);
}
.sb-uname{font-size:12px;font-weight:600;color:var(--t1)}
.sb-urole{font-size:10px;color:var(--t3)}
.sb-logout{
  margin-right:auto;background:none;border:none;
  color:var(--t3);font-size:16px;padding:4px;
  transition:color .12s;
}
.sb-logout:hover{color:var(--red)}

/* ── MAIN ── */
.main{
  margin-right:var(--sidebar);
  flex:1;min-width:0;
  display:flex;flex-direction:column;
  min-height:100vh;
}

/* ── TOPBAR ── */
.topbar{
  height:var(--topbar);
  background:var(--bg1);
  border-bottom:1px solid var(--bd);
  padding:0 20px;
  display:flex;align-items:center;gap:12px;
  position:sticky;top:0;z-index:100;
}
.topbar-menu{
  display:none;background:none;border:none;
  color:var(--t2);font-size:20px;padding:4px;
}
.breadcrumb{
  display:flex;align-items:center;gap:6px;
  font-size:12px;color:var(--t3);
}
.breadcrumb a{color:var(--t2);transition:color .1s}
.breadcrumb a:hover{color:var(--t1)}
.bc-sep{color:var(--t3)}
.bc-cur{color:var(--t1);font-weight:600}
.topbar-actions{margin-right:auto;display:flex;align-items:center;gap:8px}
.topbar-btn{
  display:flex;align-items:center;gap:5px;
  padding:5px 12px;border-radius:var(--radius-s);
  background:var(--bg3);border:1px solid var(--bd);
  font-size:12px;color:var(--t2);transition:all .12s;
}
.topbar-btn:hover{border-color:var(--ac);color:var(--ac2)}

/* ── PAGE ── */
.page{padding:20px;flex:1}

/* ── FLASH ── */
.flash{
  display:flex;align-items:center;gap:10px;
  padding:11px 14px;border-radius:var(--radius-s);
  font-size:13px;font-weight:500;margin-bottom:16px;
  animation:flashIn .2s ease;
}
@keyframes flashIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:none}}
.flash-ok {background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);color:var(--green)}
.flash-err{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);color:var(--red)}
.flash-x{margin-right:auto;background:none;border:none;color:inherit;opacity:.5;font-size:16px;cursor:pointer;padding:0}
.flash-x:hover{opacity:1}

/* ══════════ COMPONENTS ══════════ */

/* ── PAGE HEADER ── */
.ph{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:20px;flex-wrap:wrap}
.ph-left h1{font-size:20px;font-weight:700;letter-spacing:-.3px;color:var(--t1)}
.ph-left p{font-size:12px;color:var(--t3);margin-top:2px}
.ph-right{display:flex;align-items:center;gap:8px;flex-shrink:0}

/* ── CARD ── */
.card{background:var(--bg2);border:1px solid var(--bd);border-radius:var(--radius);overflow:hidden}
.card-header{
  padding:13px 16px;border-bottom:1px solid var(--bd);
  display:flex;align-items:center;justify-content:space-between;gap:10px;
}
.card-title{font-size:13px;font-weight:600;color:var(--t1)}
.card-body{padding:16px}

/* ── STATS ── */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}
.stat{
  background:var(--bg2);border:1px solid var(--bd);border-radius:var(--radius);
  padding:16px;position:relative;overflow:hidden;
  transition:border-color .15s;
}
.stat:hover{border-color:var(--bd2)}
.stat-icon{
  position:absolute;top:14px;left:14px;
  width:32px;height:32px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;font-size:16px;
}
.stat-label{font-size:11px;color:var(--t3);margin-bottom:6px}
.stat-value{font-size:22px;font-weight:800;letter-spacing:-.8px;color:var(--t1)}
.stat-sub{font-size:11px;color:var(--t3);margin-top:4px}

/* ── TABLE ── */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
thead th{
  padding:9px 14px;font-size:11px;font-weight:600;
  color:var(--t3);text-transform:uppercase;letter-spacing:.5px;
  text-align:right;border-bottom:1px solid var(--bd);white-space:nowrap;
}
tbody tr{border-bottom:1px solid var(--bd);transition:background .08s}
tbody tr:last-child{border-bottom:none}
tbody tr:hover{background:rgba(255,255,255,.02)}
td{padding:11px 14px;font-size:13px;color:var(--t1);vertical-align:middle}
.td-dim{color:var(--t2)}
.td-mono{font-family:'SF Mono',Consolas,monospace;font-size:12px}

/* ── PRODUCT ROW ── */
.prod-cell{display:flex;align-items:center;gap:10px}
.prod-img{
  width:36px;height:36px;border-radius:7px;object-fit:cover;
  border:1px solid var(--bd);background:var(--bg3);flex-shrink:0;
}
.prod-img-ph{
  width:36px;height:36px;border-radius:7px;border:1px solid var(--bd);
  background:var(--bg3);display:flex;align-items:center;justify-content:center;
  font-size:16px;flex-shrink:0;
}
.prod-name{font-size:13px;font-weight:500;color:var(--t1)}
.prod-sku{font-size:11px;color:var(--t3);margin-top:1px}

/* ── BADGES ── */
.badge{
  display:inline-flex;align-items:center;gap:3px;
  padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600;
  white-space:nowrap;
}
.badge::before{content:'';width:4px;height:4px;border-radius:50%;background:currentColor}
.badge-ok    {background:rgba(34,197,94,.1);color:var(--green)}
.badge-err   {background:rgba(239,68,68,.1);color:var(--red)}
.badge-warn  {background:rgba(245,158,11,.1);color:var(--yellow)}
.badge-info  {background:rgba(59,130,246,.1);color:var(--blue)}
.badge-purple{background:var(--acb);color:var(--ac2)}
.badge-dim   {background:rgba(255,255,255,.05);color:var(--t2)}

/* ── BUTTONS ── */
.btn{
  display:inline-flex;align-items:center;justify-content:center;gap:6px;
  padding:7px 14px;border-radius:var(--radius-s);
  font-size:13px;font-weight:500;
  border:1px solid transparent;
  transition:all .12s;cursor:pointer;
  white-space:nowrap;font-family:inherit;
}
.btn-primary{background:var(--ac);color:#fff;border-color:var(--ac)}
.btn-primary:hover{background:var(--ac2);border-color:var(--ac2)}
.btn-secondary{background:var(--bg3);color:var(--t1);border-color:var(--bd)}
.btn-secondary:hover{border-color:var(--bd2)}
.btn-danger{background:rgba(239,68,68,.08);color:var(--red);border-color:rgba(239,68,68,.2)}
.btn-danger:hover{background:var(--red);color:#fff;border-color:var(--red)}
.btn-sm{padding:5px 10px;font-size:12px}
.btn-full{width:100%}

/* ── FORMS ── */
.form-grid{display:grid;gap:14px}
.form-row-2{grid-template-columns:1fr 1fr}
.form-row-3{grid-template-columns:1fr 1fr 1fr}
.form-group{display:flex;flex-direction:column;gap:5px}
.form-label{font-size:12px;font-weight:500;color:var(--t2)}
.form-label span{color:var(--red);margin-right:2px}
.form-hint{font-size:11px;color:var(--t3)}
.form-input,.form-select,.form-textarea{
  background:var(--bg);border:1px solid var(--bd);
  border-radius:var(--radius-s);color:var(--t1);
  padding:8px 12px;font-size:13px;
  font-family:inherit;outline:none;width:100%;
  transition:border-color .12s,box-shadow .12s;
}
.form-input:focus,.form-select:focus,.form-textarea:focus{
  border-color:var(--ac);
  box-shadow:0 0 0 3px rgba(124,92,252,.1);
}
.form-input::placeholder{color:var(--t3)}
.form-textarea{resize:vertical;min-height:88px;line-height:1.6}
.form-select{appearance:none}
.toggle-wrap{display:flex;align-items:center;gap:10px}
.toggle{position:relative;width:36px;height:20px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0;position:absolute}
.toggle-slider{
  position:absolute;inset:0;background:var(--bd2);
  border-radius:20px;cursor:pointer;transition:background .15s;
}
.toggle-slider::before{
  content:'';position:absolute;width:14px;height:14px;
  right:3px;top:3px;background:#fff;border-radius:50%;transition:transform .15s;
}
.toggle input:checked + .toggle-slider{background:var(--ac)}
.toggle input:checked + .toggle-slider::before{transform:translateX(-16px)}

/* ── FILTER BAR ── */
.filter-bar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
.search-box{
  position:relative;flex:1;min-width:180px;
}
.search-box svg{
  position:absolute;right:10px;top:50%;transform:translateY(-50%);
  color:var(--t3);pointer-events:none;
}
.search-input{
  width:100%;background:var(--bg2);border:1px solid var(--bd);
  border-radius:var(--radius-s);color:var(--t1);
  padding:7px 34px 7px 12px;font-size:13px;outline:none;
  transition:border-color .12s;
}
.search-input:focus{border-color:var(--ac)}
.search-input::placeholder{color:var(--t3)}
.filter-select{
  background:var(--bg2);border:1px solid var(--bd);
  border-radius:var(--radius-s);color:var(--t2);
  padding:7px 12px;font-size:13px;outline:none;cursor:pointer;
}

/* ── PAGINATION ── */
.pagination{display:flex;justify-content:center;gap:4px;padding:14px}
.page-btn{
  width:30px;height:30px;display:flex;align-items:center;justify-content:center;
  border-radius:6px;font-size:12px;font-weight:500;
  background:var(--bg3);border:1px solid var(--bd);color:var(--t2);
  transition:all .1s;text-decoration:none;
}
.page-btn:hover{border-color:var(--ac);color:var(--ac2)}
.page-btn.active{background:var(--ac);border-color:var(--ac);color:#fff}

/* ── EMPTY STATE ── */
.empty{text-align:center;padding:52px 20px}
.empty-icon{font-size:44px;margin-bottom:14px}
.empty-title{font-size:16px;font-weight:600;color:var(--t1);margin-bottom:6px}
.empty-desc{font-size:13px;color:var(--t3);margin-bottom:18px}

/* ── MODAL ── */
.modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,.65);
  z-index:500;align-items:center;justify-content:center;
  backdrop-filter:blur(4px);
}
.modal-overlay.open{display:flex}
.modal{
  background:var(--bg2);border:1px solid var(--bd);
  border-radius:14px;padding:26px;
  width:100%;max-width:380px;
  animation:modalIn .18s ease;
}
@keyframes modalIn{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:none}}
.modal-icon{font-size:36px;margin-bottom:10px}
.modal h3{font-size:16px;font-weight:700;color:var(--t1);margin-bottom:5px}
.modal p{font-size:13px;color:var(--t2);margin-bottom:22px}
.modal-actions{display:flex;gap:8px;justify-content:flex-end}

/* ── TABS ── */
.tab-bar{display:flex;gap:2px;border-bottom:1px solid var(--bd);margin-bottom:20px}
.tab-btn{
  padding:8px 16px;font-size:13px;font-weight:500;color:var(--t2);
  background:none;border:none;border-bottom:2px solid transparent;
  cursor:pointer;transition:color .12s,border-color .12s;
  margin-bottom:-1px;
}
.tab-btn:hover{color:var(--t1)}
.tab-btn.active{color:var(--ac2);border-bottom-color:var(--ac)}

/* ══════════ RESPONSIVE ══════════ */
@media(max-width:960px){
  .sidebar{transform:translateX(100%)}
  .sidebar.open{transform:translateX(0);box-shadow:-4px 0 24px rgba(0,0,0,.5)}
  .main{margin-right:0}
  .topbar-menu{display:flex}
  .stats{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:580px){
  .stats{grid-template-columns:1fr 1fr}
  .page{padding:14px}
  .form-row-2,.form-row-3{grid-template-columns:1fr}
}

/* Aliases for backward compatibility */
.page-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:20px;flex-wrap:wrap}
.page-header-left h1{font-size:20px;font-weight:700;letter-spacing:-.3px;color:var(--t1)}
.page-header-left p{font-size:12px;color:var(--t3);margin-top:2px}
.page-header-actions{display:flex;gap:8px;align-items:center;flex-shrink:0}
.btn-secondary{background:var(--bg3);color:var(--t1);border:1px solid var(--bd);display:inline-flex;align-items:center;gap:5px;padding:7px 14px;border-radius:var(--radius-s);font-size:13px;font-weight:500;cursor:pointer;transition:all .12s;font-family:inherit;white-space:nowrap}
.btn-secondary:hover{border-color:var(--bd2)}
</style>
<?php if(!empty($extraHead)) echo $extraHead; ?>
</head>
<body>

<!-- ─── CONFIRM MODAL ─────────────────────────────────── -->
<div class="modal-overlay" id="confirm-modal">
  <div class="modal">
    <div class="modal-icon">🗑️</div>
    <h3 id="confirm-title">هل أنت متأكد؟</h3>
    <p id="confirm-desc">لا يمكن التراجع عن هذه العملية.</p>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="closeConfirm()">إلغاء</button>
      <form id="confirm-form" method="POST" style="display:inline">
        <input type="hidden" name="_csrf" value="<?php try{echo Session::csrf();}catch(\Throwable $e){} ?>">
        <button type="submit" class="btn btn-danger">تأكيد الحذف</button>
      </form>
    </div>
  </div>
</div>

<div class="layout">

<!-- ─── SIDEBAR ────────────────────────────────────────── -->
<aside class="sidebar" id="sidebar">
  <div class="sb-logo">
    <div class="sb-logo-mark">⚡</div>
    <div class="sb-logo-text">
      <?= htmlspecialchars($_name) ?>
      <small>لوحة التحكم</small>
    </div>
  </div>

  <nav class="sb-nav">
    <?php
    $nav = [
      ['sec' => 'الرئيسية'],
      ['url'=>"/$_pfx",           'icon'=>'🏠', 'label'=>'الرئيسية',   'pat'=>"/$_pfx(/dashboard)?$"],
      ['url'=>"/$_pfx/analytics", 'icon'=>'📊', 'label'=>'التحليلات',  'pat'=>"/$_pfx/analytics"],
      ['sec' => 'المتجر'],
      ['url'=>"/$_pfx/products",   'icon'=>'📦', 'label'=>'المنتجات',   'pat'=>"/$_pfx/products"],
      ['url'=>"/$_pfx/warehouse",'icon'=>'🏭','label'=>'المخزن','pat'=>"/$_pfx/warehouse"],
      ['url'=>"/$_pfx/collections",'icon'=>'🗂️', 'label'=>'التصنيفات',  'pat'=>"/$_pfx/collections"],
      ['url'=>"/$_pfx/brands",     'icon'=>'🏷️', 'label'=>'الماركات',   'pat'=>"/$_pfx/brands"],
      ['sec' => 'المبيعات'],
      ['url'=>"/$_pfx/orders",    'icon'=>'🛒', 'label'=>'الطلبات',    'pat'=>"/$_pfx/orders", 'badge'=>$_pend],
      ['url'=>"/$_pfx/customers", 'icon'=>'👥', 'label'=>'العملاء',    'pat'=>"/$_pfx/customers"],
      ['url'=>"/$_pfx/discounts", 'icon'=>'🎟️', 'label'=>'الخصومات',   'pat'=>"/$_pfx/discounts"],
      ['url'=>"/$_pfx/reviews",   'icon'=>'⭐', 'label'=>'التقييمات',  'pat'=>"/$_pfx/reviews"],
      ['sec' => 'النظام'],
      ['url'=>"/$_pfx/settings",  'icon'=>'⚙️', 'label'=>'الإعدادات',  'pat'=>"/$_pfx/settings"],
    ];
    foreach ($nav as $n):
      if (isset($n['sec'])): ?>
        <div class="sb-section"><?= $n['sec'] ?></div>
      <?php continue; endif;
      $active = nav_active($n['pat'], $_uri);
    ?>
      <a href="<?= $n['url'] ?>" class="sb-link <?= $active ?>">
        <span class="sb-icon"><?= $n['icon'] ?></span>
        <?= htmlspecialchars($n['label']) ?>
        <?php if (!empty($n['badge']) && $n['badge'] > 0): ?>
          <span class="sb-badge"><?= $n['badge'] ?></span>
        <?php endif; ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <div class="sb-footer">
    <div class="sb-user">
      <div class="sb-avatar"><?= mb_substr($_user['name'] ?? 'A', 0, 1) ?></div>
      <div>
        <div class="sb-uname"><?= htmlspecialchars($_user['name'] ?? 'Admin') ?></div>
        <div class="sb-urole"><?= htmlspecialchars($_user['role'] ?? '') ?></div>
      </div>
      <a href="/<?= $_pfx ?>/logout" class="sb-logout" title="تسجيل الخروج">⎋</a>
    </div>
  </div>
</aside>

<!-- ─── MAIN ─────────────────────────────────────────── -->
<div class="main">

  <!-- TOPBAR -->
  <header class="topbar">
    <button class="topbar-menu" onclick="toggleSidebar()" title="القائمة">☰</button>

    <nav class="breadcrumb">
      <a href="/<?= $_pfx ?>">الرئيسية</a>
      <?php if (!empty($breadcrumb)): foreach ($breadcrumb as $i => $cr): ?>
        <span class="bc-sep">/</span>
        <?php if ($i === count($breadcrumb) - 1): ?>
          <span class="bc-cur"><?= htmlspecialchars($cr['label']) ?></span>
        <?php else: ?>
          <a href="<?= htmlspecialchars($cr['url'] ?? '#') ?>"><?= htmlspecialchars($cr['label']) ?></a>
        <?php endif; ?>
      <?php endforeach; endif; ?>
    </nav>

    <div class="topbar-actions">
      <a href="/" target="_blank" class="topbar-btn">
        <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
          <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
        </svg>
        عرض المتجر
      </a>
    </div>
  </header>

  <!-- PAGE -->
  <main class="page">
    <?php
    try {
      if ($s = Session::flash('success')): ?>
        <div class="flash flash-ok">
          ✅ <?= htmlspecialchars($s) ?>
          <button class="flash-x" onclick="this.parentElement.remove()">×</button>
        </div>
      <?php endif;
      if ($e = Session::flash('error')): ?>
        <div class="flash flash-err">
          ⚠️ <?= htmlspecialchars($e) ?>
          <button class="flash-x" onclick="this.parentElement.remove()">×</button>
        </div>
      <?php endif;
    } catch (\Throwable $e) {}
    if (!empty($content)) echo $content;
    ?>
  </main>
</div><!-- /.main -->
</div><!-- /.layout -->

<script>
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}
document.addEventListener('click', e => {
  const sb = document.getElementById('sidebar');
  if (window.innerWidth <= 960 && sb.classList.contains('open')
      && !sb.contains(e.target) && !e.target.closest('.topbar-menu')) {
    sb.classList.remove('open');
  }
});

function confirmDelete(url, title, desc) {
  document.getElementById('confirm-title').textContent = title || 'هل أنت متأكد؟';
  document.getElementById('confirm-desc').textContent  = desc  || 'لا يمكن التراجع عن هذه العملية.';
  document.getElementById('confirm-form').action = url;
  document.getElementById('confirm-modal').classList.add('open');
}
function closeConfirm() {
  document.getElementById('confirm-modal').classList.remove('open');
}
document.getElementById('confirm-modal').addEventListener('click', e => {
  if (e.target === document.getElementById('confirm-modal')) closeConfirm();
});

// Auto-dismiss flash
setTimeout(() => {
  document.querySelectorAll('.flash').forEach(el => el.remove());
}, 5000);

function mkSlug(v) {
  return v.trim().toLowerCase()
    .replace(/\s+/g,'-').replace(/[^a-z0-9\-]/g,'')
    .replace(/--+/g,'-').replace(/^-+|-+$/g,'');
}
<?php if (!empty($extraScript)) echo $extraScript; ?>
</script>
</body>
</html>
