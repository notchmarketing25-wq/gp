<?php
$pageTitle  = 'منتجات غير مرتبطة';
$breadcrumb = [['label' => 'الطلبات', 'url' => adminUrl('orders')], ['label' => 'منتجات غير مرتبطة']];
ob_start();
?>
<div class="ph">
  <div class="ph-left">
    <h1>منتجات غير مرتبطة</h1>
    <p>عناصر طلبات قديمة كان منتجها محذوفًا — اربطها باسمها بمنتج حالي (مفيد لو مش عارف SKU المنتج القديم)</p>
  </div>
  <div class="ph-right">
    <a href="<?= adminUrl('orders') ?>" class="btn btn-secondary">← رجوع للطلبات</a>
  </div>
</div>

<?php if (empty($groups)): ?>
  <div class="card" style="padding:40px;text-align:center;color:var(--t3)">
    🎉 كل عناصر الطلبات مرتبطة بمنتجات حالية — لا يوجد شيء يحتاج ربط.
  </div>
<?php else: ?>
  <div class="card">
    <div class="card-header">
      <span class="card-title">مجموعات غير مرتبطة (<?= count($groups) ?>)</span>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>اسم المنتج (كما حُفظ في الطلب)</th>
            <th>SKU القديم</th>
            <th>عدد الطلبات</th>
            <th>عدد العناصر</th>
            <th>إجمالي الكمية</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($groups as $g): ?>
            <tr>
              <td>
                <div class="prod-cell">
                  <?php if ($g['image']): ?>
                    <img src="<?= uploadUrl($g['image']) ?>" class="prod-img" alt="">
                  <?php else: ?>
                    <div class="prod-img-ph">📦</div>
                  <?php endif; ?>
                  <div class="prod-name"><?= e($g['name']) ?></div>
                </div>
              </td>
              <td class="td-mono td-dim"><?= e($g['sku'] ?: '—') ?></td>
              <td><?= number_format($g['orders_count']) ?></td>
              <td><?= number_format($g['items']) ?></td>
              <td><?= number_format($g['total_qty']) ?></td>
              <td>
                <button class="btn btn-primary btn-sm" onclick="openLinkModal(<?= htmlspecialchars(json_encode($g['name']), ENT_QUOTES) ?>)">
                  🔗 اربط بمنتج
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endif; ?>

<!-- Link-to-product modal -->
<div class="modal-overlay" id="linkModal">
  <div class="modal" style="max-width:460px">
    <div class="modal-head">
      <h3>ربط بمنتج</h3>
      <button class="btn btn-ghost btn-icon" onclick="document.getElementById('linkModal').classList.remove('open')" style="font-size:18px">×</button>
    </div>
    <p style="color:var(--t2);font-size:13px;margin-bottom:12px">
      كل الطلبات القديمة باسم "<b id="linkOrphanName"></b>" ستُربط بالمنتج اللي تختاره تحت.
    </p>
    <div class="form-group" style="position:relative;margin-bottom:12px">
      <label class="form-label">اختر المنتج</label>
      <input type="text" id="linkSearchInput" class="form-input" placeholder="اكتب اسم المنتج أو SKU..." autocomplete="off" oninput="linkSearch(this.value)">
      <input type="hidden" id="linkProductId">
      <div id="linkSearchResults" style="position:absolute;z-index:10;top:100%;right:0;left:0;background:var(--bg2);border:1px solid var(--bd);border-radius:8px;max-height:220px;overflow-y:auto;display:none;margin-top:4px"></div>
    </div>
    <div id="linkSelectedPreview" style="display:none;align-items:center;gap:8px;background:var(--bg3);border-radius:8px;padding:8px;margin-bottom:16px">
      <img id="linkSelectedImg" style="width:32px;height:32px;object-fit:cover;border-radius:6px">
      <span id="linkSelectedName" style="font-weight:600;font-size:13px"></span>
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" onclick="document.getElementById('linkModal').classList.remove('open')">إلغاء</button>
      <button class="btn btn-primary" onclick="submitLink()">تأكيد الربط</button>
    </div>
  </div>
</div>

<script>
const LINK_SEARCH_URL = '<?= adminUrl('products/search-json') ?>';
const LINK_SUBMIT_URL = '<?= adminUrl('orders/orphans/link') ?>';
const LINK_CSRF = '<?= addslashes(Session::csrf()) ?>';

let _linkOrphanName = '';
let _linkSearchTimer = null;

function openLinkModal(name) {
  _linkOrphanName = name;
  document.getElementById('linkOrphanName').textContent = name;
  document.getElementById('linkSearchInput').value = '';
  document.getElementById('linkProductId').value = '';
  document.getElementById('linkSelectedPreview').style.display = 'none';
  document.getElementById('linkSearchResults').style.display = 'none';
  document.getElementById('linkModal').classList.add('open');
}

function linkSearch(q) {
  clearTimeout(_linkSearchTimer);
  const box = document.getElementById('linkSearchResults');
  if (q.trim().length < 2) { box.style.display = 'none'; return; }
  _linkSearchTimer = setTimeout(async () => {
    const r = await fetch(LINK_SEARCH_URL + '?q=' + encodeURIComponent(q));
    const items = await r.json();
    box.innerHTML = items.map(p =>
      '<div onclick="linkPick(' + p.id + ',' + JSON.stringify(p.name) + ',' + JSON.stringify(p.thumbnail_url||'') + ')" ' +
      'style="display:flex;align-items:center;gap:8px;padding:8px;cursor:pointer;border-bottom:1px solid var(--bd)">' +
      '<img src="' + (p.thumbnail_url||'') + '" style="width:28px;height:28px;object-fit:cover;border-radius:5px;background:var(--bg3)">' +
      '<div><div style="font-size:13px;font-weight:600">' + p.name + '</div><div style="font-size:11px;color:var(--t3)">' + (p.sku||'—') + '</div></div>' +
      '</div>'
    ).join('') || '<div style="padding:10px;color:var(--t3);font-size:12px">لا توجد نتائج</div>';
    box.style.display = 'block';
  }, 250);
}

function linkPick(id, name, thumb) {
  document.getElementById('linkProductId').value = id;
  document.getElementById('linkSearchInput').value = name;
  document.getElementById('linkSearchResults').style.display = 'none';
  document.getElementById('linkSelectedPreview').style.display = 'flex';
  document.getElementById('linkSelectedName').textContent = name;
  document.getElementById('linkSelectedImg').src = thumb || '';
}

async function submitLink() {
  const pid = document.getElementById('linkProductId').value;
  if (!pid) { alert('اختر منتج من نتائج البحث أولاً'); return; }
  const fd = new FormData();
  fd.append('name', _linkOrphanName);
  fd.append('product_id', pid);
  fd.append('_csrf', LINK_CSRF);
  const r = await fetch(LINK_SUBMIT_URL, {method:'POST', body:fd});
  const d = await r.json();
  if (d.success) { location.reload(); } else { alert(d.message || 'خطأ'); }
}

document.getElementById('linkModal')?.addEventListener('click', e => {
  if (e.target === document.getElementById('linkModal')) document.getElementById('linkModal').classList.remove('open');
});
</script>

<?php
$content = ob_get_clean();
require APP_PATH . '/Views/admin/layouts/app.php';
